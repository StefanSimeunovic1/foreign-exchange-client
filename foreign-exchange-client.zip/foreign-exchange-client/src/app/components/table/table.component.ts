import { Component, OnInit, Input } from '@angular/core';
import { ExchangeRatesServiceService } from 'src/app/service/exchange-rates-service.service';
import { IExchnageRate } from 'src/app/entity/exchange-rates';
import { CurrencyService } from 'src/app/service/currency.service';
import { ICurrency } from 'src/app/entity/currency';
import { FormGroup } from '@angular/forms';
import { IOrder } from 'src/app/entity/order';
import { OrderService } from 'src/app/service/order.service';
import { MatDialog } from '@angular/material/dialog';
import { SuccessDialogComponent } from 'src/app/dialog/success-dialog/success-dialog.component';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})

export class TableComponent implements OnInit {
  EUR_CURRENCY = "EUR";
  EXCHANGE_RATE = "exchangeRate";
  elementData: any[] = [];
  dataSource: any;
  displayedColumns: any[] = [];
  externalRates: any = [];
  internalRates: Array<IExchnageRate> = [];
  amountOfDesiredCurrency = 0;
  calculatedAmountInUSD: any | undefined;
  currentExchangeRate: any;
  feeAmount: any;
  discountAmount: any;
  selectedCurrency: ICurrency = {
    abbreviation: "",
    country: "",
    discount: 0,
    fee: 0,
    name: ""
  };

  order: IOrder = {
    surchargePercentage: 0,
    surchargeAmount: 0,
    purchasedAmount: 0,
    paidAmount: 0,
    discountPercentage: 0,
    discountAmount: 0,
    exchangeRate: 0,
    purchasedCurrency: this.selectedCurrency
  }

  constructor(private  exchnageService: ExchangeRatesServiceService,
              private currencyService: CurrencyService,
              private orderService: OrderService,
              private dialog: MatDialog) {}
  
  @Input() set setHeaders(headers: any) {
    this.displayedColumns = headers;
  }

  ngOnInit(): void {
    this.currencyService.getAll().subscribe((data: any) => {
      this.dataSource = data;
    });
    this.exchnageService.getLatestExternalRates().subscribe((data: any) => {
      this.externalRates = data.quotes;

      this.exchnageService.getInternalRates().subscribe((data: any) => {
        this.internalRates =  data;

        this.internalRates.forEach(x =>{
          x.exchangeRate = x.exchangeRate !== this.externalRates[x.abbreviation] ? this.externalRates[x.abbreviation] : x.exchangeRate;
          this.exchnageService.updateExchnageRates(x).subscribe((data: any) => {
          });
        })
      });
    });
  }

  selectItem(row: any) {
    this.selectedCurrency = row;
    this.amountOfDesiredCurrency = 0;
    this.calculatedAmountInUSD = 0;
  }
  buyCurrency() {
    this.order.purchasedCurrency = this.selectedCurrency;
    this.order.discountAmount = this.discountAmount;
    this.order.discountPercentage = this.selectedCurrency.discount;
    this.order.exchangeRate = this.currentExchangeRate[this.EXCHANGE_RATE];
    this.order.paidAmount = this.calculatedAmountInUSD;
    this.order.purchasedAmount = this.amountOfDesiredCurrency;
    this.order.surchargeAmount = this.feeAmount;
    this.order.surchargePercentage = this.selectedCurrency.fee;
    this.orderService.saveOrder(this.order).subscribe((data: any) => {
      this.dialog.open(SuccessDialogComponent);
    });
  }
  calculate() {
    this.currentExchangeRate = this.internalRates.find(x => x.abbreviation.endsWith(this.selectedCurrency.abbreviation));
    this.calculatedAmountInUSD = this.amountOfDesiredCurrency * this.currentExchangeRate[this.EXCHANGE_RATE] * this.calculateFee();
    this.feeAmount = this.calculatedAmountInUSD - this.amountOfDesiredCurrency * this.currentExchangeRate[this.EXCHANGE_RATE];
    this.shouldCalculateDiscount(this.selectedCurrency.abbreviation == this.EUR_CURRENCY);
    this.discountAmount = this.selectedCurrency.discount > 0 ? this.amountOfDesiredCurrency * this.currentExchangeRate[this.EXCHANGE_RATE] * this.calculateFee() - this.calculatedAmountInUSD : 0;
  }

  calculateFee(): number {
    return (100 + this.selectedCurrency.fee) / 100;
  }

  calculateDiscount(): number {
    return (100 - this.selectedCurrency.discount) / 100;
  }

  shouldCalculateDiscount(should: boolean): void {
    if (should){
      this.calculatedAmountInUSD = this.amountOfDesiredCurrency * this.currentExchangeRate[this.EXCHANGE_RATE] * this.calculateFee() * this.calculateDiscount();
    }
  }
}
