export const environment = {
    baseURL: 'http://localhost:8080/',
    getAllUrl: 'getAll',
    saveUrl: 'save',
    internalRatesUrl: 'currency-rates/',
    orderURL: 'orders/',
    currencyURl: 'currencies/',
    externalRatesUrl: 'http://api.currencylayer.com/live?access_key=0bc24b207a7b78853e768c7666d650c8'
  };