import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations' ;
import { TableComponent } from './components/table/table.component';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ExchangeRatesServiceService } from '././service/exchange-rates-service.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SuccessDialogComponent } from './dialog/success-dialog/success-dialog.component';

@NgModule({
  declarations: [
    AppComponent,
    TableComponent,
    SuccessDialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ExchangeRatesServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
