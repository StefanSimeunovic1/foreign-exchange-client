import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IOrder } from '../entity/order';
import { environment } from '../environment';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) { }

  saveOrder(order: IOrder): Observable<any> {
    return this.http.post(environment.baseURL + environment.orderURL + environment.saveUrl, order);
  }

}
