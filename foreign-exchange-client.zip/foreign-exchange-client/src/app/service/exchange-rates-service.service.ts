import { Injectable } from '@angular/core';
import { HttpClient, } from '@angular/common/http';
import { environment } from '../environment';
import { IExchnageRate } from '../entity/exchange-rates';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ExchangeRatesServiceService {

  updateRatesUrl: string = 'updateRates'

  constructor(private http: HttpClient) { }

  getLatestExternalRates() {
    return this.http.get(environment.externalRatesUrl);
  }
  
  getInternalRates(){
    return this.http.get(environment.baseURL + environment.internalRatesUrl + environment.getAllUrl);
  }

  updateExchnageRates(exchangeRate: IExchnageRate): Observable<any> {
    return this.http.put(environment.baseURL + environment.internalRatesUrl + this.updateRatesUrl, exchangeRate);
  }
}
