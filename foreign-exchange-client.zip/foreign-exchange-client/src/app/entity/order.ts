import { ICurrency } from "./currency";

export interface IOrder {
    surchargePercentage: number;
    surchargeAmount: number;
    purchasedAmount: number;
    paidAmount: number;
    discountPercentage: number;
    discountAmount: number;
    exchangeRate: number;
    purchasedCurrency: ICurrency
}