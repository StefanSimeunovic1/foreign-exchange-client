import { ICurrency } from "./currency";

export interface IExchnageRate {
    id: number;
    fromCurrency: ICurrency;
    toCurrency: ICurrency;
    exchangeRate: number | undefined;
    abbreviation: string;
}