export interface ICurrency {
    name: string;
    abbreviation: string;
    country: string;
    fee: number;
    discount: number;
}