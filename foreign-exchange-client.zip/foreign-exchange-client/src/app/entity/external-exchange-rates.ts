export interface IExternalExchangeRates {
    id: number;
    exchangeRate: number | undefined;
    abbreviation: string;
}